Reece Gerhart \& Mason Lohnes | CST-305 Project 6 | Ricardo Citro



Necessary programs:
Python3:
	sudo apt install python3 python3-pip -y

NumPy, Matplotlib, and SciPy:
	python3 -m pip install --upgrade pip
	python3 -m pip install numpy matplotlib scipy



Download the TaylorPolynomials.py file to your device.
run ls to ensure the file is accessible by the terminal
RUN: python3 TaylorPolynomials.py

